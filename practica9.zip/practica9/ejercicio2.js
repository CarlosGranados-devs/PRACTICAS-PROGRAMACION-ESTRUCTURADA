// ⚙️ Ejercicio 2: Mini Calculadora con funciones

function suma(num1, num2) {
  return num1 + num2;
}

function resta(num1, num2) {
  return num1 - num2;
}

function division(num1, num2) {
  if (num2 === 0) {
    return "Error: no se puede dividir entre cero.";
  }
  return num1 / num2;
}

function multiplicacion(num1, num2) {
  return num1 * num2;
}

function ejecutarOperacion(operacion, a, b) {
  const resultado = operacion(a, b);
  console.log(`Resultado de la operación: ${resultado}`);
}

// Ejemplos de uso
ejecutarOperacion(suma, 8, 12);
ejecutarOperacion(multiplicacion, 6, 4);
