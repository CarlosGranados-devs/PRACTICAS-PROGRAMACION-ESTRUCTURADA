// 📘 Ejercicio 1: Promedio de Calificaciones

function obtenerPromedio(calificaciones) {
  let total = 0;
  for (const nota of calificaciones) {
    total += nota;
  }
  return total / calificaciones.length;
}

const mostrarPromedio = function(estudiante, promedio) {
  console.log(`El promedio de ${estudiante} es: ${promedio.toFixed(2)}`);
};

const clasificarDesempeño = (promedio) => {
  if (promedio >= 9) return "Sobresaliente";
  else if (promedio >= 6.5) return "Aprobado";
  else return "Reprobado";
};

const notasSofia = [9, 8, 7, 10];
const promedioFinal = obtenerPromedio(notasSofia);

mostrarPromedio("Sofía", promedioFinal);
console.log("Nivel de desempeño:", clasificarDesempeño(promedioFinal));
